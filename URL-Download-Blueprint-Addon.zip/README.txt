Thank you for purchasing URL Downloader – Blueprint Addon

Instantly download files from any HTTP/HTTPS URL directly into your server's /home/container directory.

🔥 What This Addon Does

This addon adds a URL Download button inside the server file manager.
With one click, users can paste a URL and the panel will run:


curl <url> -O


Automatically placing the file inside the container folder.
Super quick, super simple.

✔ Works for any user with Console permission
✔ Supports HTTP & HTTPS
✔ Clean UI integrated directly into the panel
✔ No config required — just install and use

📦 Features

One-click file downloads
Uses secure curl from the container
No panel modifications required beyond the Blueprint
Lightweight & fast
Works on all Linux-based Pterodactyl environments

🛠 Requirements
Pterodactyl Panel with Blueprint support
Server must have curl installed (default on most distros)

👤 Credits
Addon Author: an.average.being
Branding by: Slice Studios (studios.slice.wtf)

🌐 Official Links
🌍 Website: https://studios.slice.wtf
💬 Discord: https://discord.gg/QE7kaDp5Uw
🛡 Product Page: https://studios.slice.wtf

📥 Installation
Upload the .blueprint file to your panel.
Enable the addon.
Refresh your panel’s File Manager page.
Enjoy your shiny new URL Download button.

📄 License
This addon is provided under a simple personal-use license and can be used only on one panel per purchase at a time.
Redistribution, reselling, or rebranding without permission is not allowed.
