<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::table('email_logs', function (Blueprint $table) {
            if (!Schema::hasColumn('email_logs', 'log_uuid')) {
                $table->string('log_uuid')->nullable()->index()->after('id');
            }
            if (!Schema::hasColumn('email_logs', 'html')) {
                $table->longText('html')->nullable()->after('error');
            }
            if (!Schema::hasColumn('email_logs', 'text')) {
                $table->longText('text')->nullable()->after('html');
            }
            if (!Schema::hasColumn('email_logs', 'message_id')) {
                $table->string('message_id')->nullable()->after('text');
            }
        });
    }

    public function down(): void
    {
        Schema::table('email_logs', function (Blueprint $table) {
            if (Schema::hasColumn('email_logs', 'message_id')) {
                $table->dropColumn('message_id');
            }
            if (Schema::hasColumn('email_logs', 'text')) {
                $table->dropColumn('text');
            }
            if (Schema::hasColumn('email_logs', 'html')) {
                $table->dropColumn('html');
            }
            if (Schema::hasColumn('email_logs', 'log_uuid')) {
                $table->dropColumn('log_uuid');
            }
        });
    }
};
