@extends('layouts.admin')

@section('title')
    Email Utils Logs
@endsection

@section('content-header')
    <h1>Email Utils<small>Delivery logs for notifications.</small></h1>
    <ol class="breadcrumb">
        <li><a href="{{ route('admin.index') }}">Admin</a></li>
        <li class="active">Email Utils</li>
    </ol>
@endsection

@section('content')
    <ul class="nav nav-tabs" style="margin-bottom: 15px;">
        <li><a href="{{ route('admin.email-utils') }}">Templates</a></li>
        <li class="active"><a href="{{ route('admin.email-utils.logs') }}">Logs</a></li>
    </ul>

    <div class="row">
        <div class="col-xs-12">
            <div class="box">
                <div class="box-header with-border">
                    <h3 class="box-title">Recent Email Activity</h3>
                </div>
                <div class="box-body table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>Time</th>
                                <th>Status</th>
                                <th>Template</th>
                                <th>Recipient</th>
                                <th>Notification</th>
                                <th>Response</th>
                                <th>View</th>
                            </tr>
                        </thead>
                        <tbody>
                            @forelse ($logs as $log)
                                <tr>
                                    <td>{{ $log->sent_at?->toDateTimeString() ?? $log->created_at->toDateTimeString() }}</td>
                                    <td>
                                        @if ($log->status === 'sent')
                                            <span class="label label-success">Sent</span>
                                        @else
                                            <span class="label label-danger">Failed</span>
                                        @endif
                                    </td>
                                    <td>{{ $log->template_key ?? '-' }}</td>
                                    <td>
                                        <div>{{ $log->to_email ?? '-' }}</div>
                                        @if ($log->to_name)
                                            <small class="text-muted">{{ $log->to_name }}</small>
                                        @endif
                                    </td>
                                    <td>{{ class_basename($log->notification) }}</td>
                                    <td>
                                        @if ($log->error)
                                            <div class="text-danger">{{ $log->error }}</div>
                                        @elseif ($log->response)
                                            <div class="text-muted">{{ \Illuminate\Support\Str::limit($log->response, 120) }}</div>
                                        @else
                                            <div class="text-muted">-</div>
                                        @endif
                                    </td>
                                    <td>
                                        @if ($log->html || $log->text)
                                            <a href="{{ route('admin.email-utils.logs.show', $log->id) }}" class="btn btn-xs btn-primary">View</a>
                                        @else
                                            <span class="text-muted">-</span>
                                        @endif
                                    </td>
                                </tr>
                            @empty
                                <tr>
                                    <td colspan="6" class="text-center text-muted">No email activity logged yet.</td>
                                </tr>
                            @endforelse
                        </tbody>
                    </table>
                </div>
                <div class="box-footer">
                    {{ $logs->links() }}
                </div>
            </div>
        </div>
    </div>
@endsection
