@extends('layouts.admin')

@section('title')
    Email Utils
@endsection

@section('content-header')
    <h1>Email Utils<small>Customize notification templates and delivery.</small></h1>
    <ol class="breadcrumb">
        <li><a href="{{ route('admin.index') }}">Admin</a></li>
        <li class="active">Email Utils</li>
    </ol>
@endsection

@section('content')
    <ul class="nav nav-tabs" style="margin-bottom: 15px;">
        <li class="active"><a href="{{ route('admin.email-utils') }}">Templates</a></li>
        <li><a href="{{ route('admin.email-utils.logs') }}">Logs</a></li>
    </ul>

    <div class="row">
        <div class="col-xs-12">
            @foreach ($templates as $template)
                @php
                    $model = $template['model'];
                    $config = $template['config'];
                @endphp
                <div class="box">
                    <div class="box-header with-border">
                        <h3 class="box-title">{{ $config['name'] ?? $model->name }}</h3>
                        <p class="text-muted" style="margin: 5px 0 0;">
                            <small>{{ $config['description'] ?? '' }}</small>
                        </p>
                    </div>
                    <form action="{{ route('admin.email-utils.update', $model->key) }}" method="POST" enctype="multipart/form-data">
                        <div class="box-body">
                            <div class="row">
                                <div class="form-group col-md-6">
                                    <label class="control-label">Subject</label>
                                    <input type="text" class="form-control" name="subject" value="{{ old('subject', $model->subject) }}" />
                                    <p class="text-muted"><small>Leave blank to keep the default subject.</small></p>
                                </div>
                                <div class="form-group col-md-3">
                                    <label class="control-label">Enabled</label>
                                    <div>
                                        <input type="hidden" name="is_active" value="0">
                                        <label style="font-weight: 400;">
                                            <input type="checkbox" name="is_active" value="1" {{ old('is_active', $model->is_active) ? 'checked' : '' }}> Use custom template
                                        </label>
                                    </div>
                                </div>
                                <div class="form-group col-md-3">
                                    <label class="control-label">HTML File</label>
                                    <input type="file" name="html_file" class="form-control" accept=".html,.htm,text/html" />
                                    @if ($model->html_file_path)
                                        <p class="text-muted"><small>Stored file: {{ $model->html_file_path }}</small></p>
                                        <label style="font-weight: 400;">
                                            <input type="checkbox" name="remove_file" value="1"> Remove file
                                        </label>
                                    @else
                                        <p class="text-muted"><small>Optional. Uploaded files override the HTML field.</small></p>
                                    @endif
                                </div>
                            </div>

                            <div class="row">
                                <div class="form-group col-md-6">
                                    <label class="control-label">HTML Content</label>
                                    <textarea class="form-control" name="html" rows="10">{{ old('html', $model->html) }}</textarea>
                                    <p class="text-muted"><small>Use placeholders like {{ '{' }}{{ '{' }}user.name{{ '}' }}{{ '}' }} in the HTML.</small></p>
                                </div>
                                <div class="form-group col-md-6">
                                    <label class="control-label">Text Content</label>
                                    <textarea class="form-control" name="text" rows="10">{{ old('text', $model->text) }}</textarea>
                                    <p class="text-muted"><small>Optional plain-text fallback.</small></p>
                                </div>
                            </div>

                            @if (!empty($config['placeholders']))
                                <div class="row">
                                    <div class="col-md-12">
                                        <label class="control-label">Available Placeholders</label>
                                        <div class="table-responsive">
                                            <table class="table table-bordered table-hover">
                                                <thead>
                                                    <tr>
                                                        <th>Placeholder</th>
                                                        <th>Description</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    @foreach ($config['placeholders'] as $placeholder => $description)
                                                        <tr>
                                                            <td><code>{{ $placeholder }}</code></td>
                                                            <td>{{ $description }}</td>
                                                        </tr>
                                                    @endforeach
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            @endif
                        </div>
                        <div class="box-footer">
                            {!! csrf_field() !!}
                            <button type="submit" name="_method" value="PATCH" class="btn btn-sm btn-primary pull-right">Save</button>
                        </div>
                    </form>
                </div>
            @endforeach
        </div>
    </div>
@endsection
