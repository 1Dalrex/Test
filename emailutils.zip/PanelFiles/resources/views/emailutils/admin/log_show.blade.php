@extends('layouts.admin')

@section('title')
    Email Log View
@endsection

@section('content-header')
    <h1>Email Log<small>Preview delivered email content.</small></h1>
    <ol class="breadcrumb">
        <li><a href="{{ route('admin.index') }}">Admin</a></li>
        <li><a href="{{ route('admin.email-utils.logs') }}">Email Utils</a></li>
        <li class="active">View</li>
    </ol>
@endsection

@section('content')
    <div class="row">
        <div class="col-xs-12">
            <div class="box">
                <div class="box-header with-border">
                    <h3 class="box-title">{{ $log->subject ?? 'Email Preview' }}</h3>
                    <p class="text-muted" style="margin: 5px 0 0;">
                        <small>To: {{ $log->to_email ?? 'Unknown' }} | Status: {{ ucfirst($log->status) }}</small>
                    </p>
                </div>
                <div class="box-body">
                    <ul class="nav nav-tabs" style="margin-bottom: 15px;">
                        <li class="active"><a href="#email-html" data-toggle="tab">HTML</a></li>
                        <li><a href="#email-text" data-toggle="tab">Text</a></li>
                    </ul>
                    <div class="tab-content">
                        <div class="tab-pane active" id="email-html">
                            @if ($log->html)
                                <iframe
                                    style="width: 100%; height: 600px; border: 1px solid #ddd;"
                                    src="{{ route('admin.email-utils.logs.html', $log->id) }}">
                                </iframe>
                            @else
                                <p class="text-muted">No HTML content captured for this message.</p>
                            @endif
                        </div>
                        <div class="tab-pane" id="email-text">
                            @if ($log->text)
                                <iframe
                                    style="width: 100%; height: 600px; border: 1px solid #ddd;"
                                    src="{{ route('admin.email-utils.logs.text', $log->id) }}">
                                </iframe>
                            @else
                                <p class="text-muted">No plain-text content captured for this message.</p>
                            @endif
                        </div>
                    </div>
                </div>
                <div class="box-footer">
                    <a href="{{ route('admin.email-utils.logs') }}" class="btn btn-sm btn-default">Back to Logs</a>
                </div>
            </div>
        </div>
    </div>
@endsection
