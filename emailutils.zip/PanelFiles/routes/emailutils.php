<?php

use Illuminate\Support\Facades\Route;
use Pterodactyl\Http\Controllers\Admin\EmailUtils\EmailLogController;
use Pterodactyl\Http\Controllers\Admin\EmailUtils\EmailUtilsController;

Route::get('/email-utils', [EmailUtilsController::class, 'index'])->name('admin.email-utils');
Route::patch('/email-utils/{template}', [EmailUtilsController::class, 'update'])->name('admin.email-utils.update');
Route::get('/email-utils/logs', [EmailLogController::class, 'index'])->name('admin.email-utils.logs');
Route::get('/email-utils/logs/{log}', [EmailLogController::class, 'show'])->name('admin.email-utils.logs.show');
Route::get('/email-utils/logs/{log}/html', [EmailLogController::class, 'showHtml'])->name('admin.email-utils.logs.html');
Route::get('/email-utils/logs/{log}/text', [EmailLogController::class, 'showText'])->name('admin.email-utils.logs.text');
