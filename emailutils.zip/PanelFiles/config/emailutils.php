<?php

return [
    'storage_disk' => 'local',
    'template_path' => 'emailutils/templates',
    'templates' => [
        'account_created' => [
            'name' => 'Account Created',
            'description' => 'Sent when an admin creates a new user account.',
            'default_subject' => 'Your account on {{app.name}}',
            'placeholders' => [
                '{{user.name}}' => 'Full name of the user.',
                '{{user.email}}' => 'Email address of the user.',
                '{{user.username}}' => 'Username of the user.',
                '{{token}}' => 'Account setup token (if generated).',
                '{{action.url}}' => 'Account setup link (if available).',
                '{{app.name}}' => 'Panel name from config.',
                '{{panel.url}}' => 'Panel base URL from config.',
                '{{timestamp}}' => 'Current timestamp.',
            ],
        ],
        'password_reset' => [
            'name' => 'Password Reset',
            'description' => 'Sent when a user requests a password reset.',
            'default_subject' => 'Reset Password',
            'placeholders' => [
                '{{user.email}}' => 'Email address of the user.',
                '{{token}}' => 'Password reset token.',
                '{{action.url}}' => 'Password reset link.',
                '{{app.name}}' => 'Panel name from config.',
                '{{panel.url}}' => 'Panel base URL from config.',
                '{{timestamp}}' => 'Current timestamp.',
            ],
        ],
        'server_installed' => [
            'name' => 'Server Installed',
            'description' => 'Sent when a server finishes installing.',
            'default_subject' => 'Your server is ready',
            'placeholders' => [
                '{{user.username}}' => 'Username of the server owner.',
                '{{server.name}}' => 'Name of the server.',
                '{{action.url}}' => 'Panel link.',
                '{{app.name}}' => 'Panel name from config.',
                '{{panel.url}}' => 'Panel base URL from config.',
                '{{timestamp}}' => 'Current timestamp.',
            ],
        ],
        'added_to_server' => [
            'name' => 'Added To Server',
            'description' => 'Sent when a user is added as a subuser.',
            'default_subject' => 'You were added to a server',
            'placeholders' => [
                '{{user.name}}' => 'Name of the subuser.',
                '{{server.name}}' => 'Name of the server.',
                '{{server.uuid_short}}' => 'Short UUID of the server.',
                '{{action.url}}' => 'Server link.',
                '{{app.name}}' => 'Panel name from config.',
                '{{panel.url}}' => 'Panel base URL from config.',
                '{{timestamp}}' => 'Current timestamp.',
            ],
        ],
        'removed_from_server' => [
            'name' => 'Removed From Server',
            'description' => 'Sent when a user is removed as a subuser.',
            'default_subject' => 'You were removed from a server',
            'placeholders' => [
                '{{user.name}}' => 'Name of the subuser.',
                '{{server.name}}' => 'Name of the server.',
                '{{action.url}}' => 'Panel link.',
                '{{app.name}}' => 'Panel name from config.',
                '{{panel.url}}' => 'Panel base URL from config.',
                '{{timestamp}}' => 'Current timestamp.',
            ],
        ],
        'mail_tested' => [
            'name' => 'Mail Test',
            'description' => 'Sent from the admin mail settings test.',
            'default_subject' => 'Pterodactyl Test Message',
            'placeholders' => [
                '{{user.name}}' => 'Full name of the user.',
                '{{user.email}}' => 'Email address of the user.',
                '{{app.name}}' => 'Panel name from config.',
                '{{panel.url}}' => 'Panel base URL from config.',
                '{{timestamp}}' => 'Current timestamp.',
            ],
        ],
    ],
];
