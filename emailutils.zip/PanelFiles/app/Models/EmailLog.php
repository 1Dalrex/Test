<?php

namespace Pterodactyl\Models;

use Illuminate\Database\Eloquent\Model;

class EmailLog extends Model
{
    protected $table = 'email_logs';

    protected $fillable = [
        'log_uuid',
        'template_key',
        'notification',
        'notifiable_type',
        'notifiable_id',
        'to_email',
        'to_name',
        'subject',
        'status',
        'response',
        'error',
        'sent_at',
        'html',
        'text',
        'message_id',
    ];

    protected $casts = [
        'sent_at' => 'datetime',
    ];
}
