<?php

namespace Pterodactyl\Http\Requests\Admin\EmailUtils;

use Illuminate\Foundation\Http\FormRequest;

class UpdateEmailTemplateRequest extends FormRequest
{
    public function authorize(): bool
    {
        return $this->user()?->root_admin ?? false;
    }

    public function rules(): array
    {
        return [
            'subject' => ['nullable', 'string', 'max:255'],
            'html' => ['nullable', 'string'],
            'text' => ['nullable', 'string'],
            'is_active' => ['nullable', 'boolean'],
            'html_file' => ['nullable', 'file', 'mimes:html,htm', 'max:1024'],
            'remove_file' => ['nullable', 'boolean'],
        ];
    }
}
