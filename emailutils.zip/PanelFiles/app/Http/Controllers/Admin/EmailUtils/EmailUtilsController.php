<?php

namespace Pterodactyl\Http\Controllers\Admin\EmailUtils;

use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use Pterodactyl\Http\Controllers\Controller;
use Pterodactyl\Http\Requests\Admin\EmailUtils\UpdateEmailTemplateRequest;
use Pterodactyl\Models\EmailTemplate;
use Pterodactyl\Services\EmailUtils\EmailTemplateManager;

class EmailUtilsController extends Controller
{
    public function index(Request $request)
    {
        EmailTemplateManager::syncTemplates();

        $templates = EmailTemplate::query()->orderBy('name')->get()->map(function (EmailTemplate $template) {
            $config = config('emailutils.templates.' . $template->key, []);

            return [
                'model' => $template,
                'config' => $config,
            ];
        });

        return view('emailutils::admin.index', [
            'templates' => $templates,
        ]);
    }

    public function update(UpdateEmailTemplateRequest $request, string $template): RedirectResponse
    {
        EmailTemplateManager::syncTemplates();

        $record = EmailTemplate::query()->where('key', $template)->firstOrFail();

        $record->subject = $request->input('subject');
        $record->html = $request->input('html');
        $record->text = $request->input('text');
        $record->is_active = $request->boolean('is_active');

        if ($request->boolean('remove_file')) {
            $this->deleteFileIfExists($record->html_file_path);
            $record->html_file_path = null;
        }

        if ($request->hasFile('html_file')) {
            $this->deleteFileIfExists($record->html_file_path);

            $disk = config('emailutils.storage_disk', 'local');
            $directory = trim(config('emailutils.template_path', 'emailutils/templates'), '/');
            $filename = $template . '-' . Str::random(8) . '.' . $request->file('html_file')->getClientOriginalExtension();

            $path = $request->file('html_file')->storeAs($directory, $filename, $disk);
            $record->html_file_path = $path;
        }

        $record->save();

        return back()->with('success', 'Email template updated.');
    }

    private function deleteFileIfExists(?string $path): void
    {
        if (!$path) {
            return;
        }

        $disk = config('emailutils.storage_disk', 'local');
        $path = ltrim($path, '/');

        if (Storage::disk($disk)->exists($path)) {
            Storage::disk($disk)->delete($path);
        }
    }
}
