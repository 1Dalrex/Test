<?php

namespace Pterodactyl\Http\Controllers\Admin\EmailUtils;

use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Pterodactyl\Http\Controllers\Controller;
use Pterodactyl\Models\EmailLog;

class EmailLogController extends Controller
{
    public function index(Request $request)
    {
        $logs = EmailLog::query()->orderByDesc('id')->paginate(50);

        return view('emailutils::admin.logs', [
            'logs' => $logs,
        ]);
    }

    public function show(EmailLog $log)
    {
        return view('emailutils::admin.log_show', [
            'log' => $log,
        ]);
    }

    public function showHtml(EmailLog $log): Response
    {
        if (!$log->html) {
            return response('No HTML content captured.', 404);
        }

        return response($log->html, 200, [
            'Content-Type' => 'text/html; charset=UTF-8',
        ]);
    }

    public function showText(EmailLog $log): Response
    {
        if (!$log->text) {
            return response('No text content captured.', 404);
        }

        return response($log->text, 200, [
            'Content-Type' => 'text/plain; charset=UTF-8',
        ]);
    }
}
