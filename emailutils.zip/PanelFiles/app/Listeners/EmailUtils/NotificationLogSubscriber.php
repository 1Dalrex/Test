<?php

namespace Pterodactyl\Listeners\EmailUtils;

use Illuminate\Events\Dispatcher;
use Illuminate\Notifications\Events\NotificationFailed;
use Illuminate\Notifications\Events\NotificationSent;
use Pterodactyl\Models\EmailLog;
use Pterodactyl\Services\EmailUtils\EmailTemplateManager;

class NotificationLogSubscriber
{
    public function handleNotificationSent(NotificationSent $event): void
    {
        if ($event->channel !== 'mail') {
            return;
        }

        $templateKey = EmailTemplateManager::resolveTemplateKey($event->notification);
        $data = EmailTemplateManager::resolveTemplateData($event->notification, $event->notifiable);
        $meta = EmailTemplateManager::getNotificationMeta($event->notification);

        EmailLog::query()->create([
            'template_key' => $templateKey,
            'notification' => $event->notification::class,
            'notifiable_type' => $this->resolveNotifiableType($event->notifiable),
            'notifiable_id' => $this->resolveNotifiableId($event->notifiable),
            'to_email' => $this->resolveRecipient($event->notifiable),
            'to_name' => $this->resolveRecipientName($event->notifiable),
            'log_uuid' => $meta['log_id'] ?? null,
            'subject' => $meta['subject'] ?? ($templateKey ? EmailTemplateManager::renderSubject($templateKey, $data ?? []) : null),
            'status' => 'sent',
            'response' => $this->stringifyResponse($event),
            'sent_at' => now(),
            'html' => $meta['html'] ?? null,
            'text' => $meta['text'] ?? null,
        ]);
    }

    public function handleNotificationFailed(NotificationFailed $event): void
    {
        if ($event->channel !== 'mail') {
            return;
        }

        $templateKey = EmailTemplateManager::resolveTemplateKey($event->notification);
        $data = EmailTemplateManager::resolveTemplateData($event->notification, $event->notifiable);
        $meta = EmailTemplateManager::getNotificationMeta($event->notification);

        EmailLog::query()->create([
            'template_key' => $templateKey,
            'notification' => $event->notification::class,
            'notifiable_type' => $this->resolveNotifiableType($event->notifiable),
            'notifiable_id' => $this->resolveNotifiableId($event->notifiable),
            'to_email' => $this->resolveRecipient($event->notifiable),
            'to_name' => $this->resolveRecipientName($event->notifiable),
            'log_uuid' => $meta['log_id'] ?? null,
            'subject' => $meta['subject'] ?? ($templateKey ? EmailTemplateManager::renderSubject($templateKey, $data ?? []) : null),
            'status' => 'failed',
            'response' => $this->stringifyResponse($event),
            'error' => $this->stringifyError($event),
            'html' => $meta['html'] ?? null,
            'text' => $meta['text'] ?? null,
        ]);
    }

    public function subscribe(Dispatcher $events): void
    {
        $events->listen(NotificationSent::class, [self::class, 'handleNotificationSent']);
        $events->listen(NotificationFailed::class, [self::class, 'handleNotificationFailed']);
    }

    private function resolveRecipient(mixed $notifiable): ?string
    {
        if ($notifiable === null) {
            return null;
        }

        if (method_exists($notifiable, 'routeNotificationFor')) {
            $route = $notifiable->routeNotificationFor('mail');
            if (is_array($route)) {
                return implode(', ', $route);
            }

            if (is_string($route)) {
                return $route;
            }
        }

        return $notifiable->email ?? null;
    }

    private function resolveRecipientName(mixed $notifiable): ?string
    {
        if ($notifiable === null) {
            return null;
        }

        if (isset($notifiable->name)) {
            return $notifiable->name;
        }

        if (isset($notifiable->name_first)) {
            return $notifiable->name_first;
        }

        return null;
    }

    private function resolveNotifiableType(mixed $notifiable): ?string
    {
        if ($notifiable === null) {
            return null;
        }

        if (method_exists($notifiable, 'getMorphClass')) {
            return $notifiable->getMorphClass();
        }

        return $notifiable::class;
    }

    private function resolveNotifiableId(mixed $notifiable): ?int
    {
        if ($notifiable === null) {
            return null;
        }

        if (method_exists($notifiable, 'getKey')) {
            return $notifiable->getKey();
        }

        return null;
    }

    private function stringifyResponse(object $event): ?string
    {
        if (property_exists($event, 'response') && $event->response !== null) {
            if (is_string($event->response)) {
                return $event->response;
            }

            return json_encode($event->response, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
        }

        return null;
    }

    private function stringifyError(object $event): ?string
    {
        if (property_exists($event, 'exception') && $event->exception !== null) {
            return $event->exception->getMessage();
        }

        return null;
    }
}
