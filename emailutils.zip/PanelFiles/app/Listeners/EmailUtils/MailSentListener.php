<?php

namespace Pterodactyl\Listeners\EmailUtils;

use Illuminate\Mail\Events\MessageSent;
use Pterodactyl\Models\EmailLog;

class MailSentListener
{
    public function handle(MessageSent $event): void
    {
        $message = $event->message;
        if (!method_exists($message, 'getHeaders')) {
            return;
        }

        $headers = $message->getHeaders();
        $templateHeader = $headers->get('X-Email-Utils-Template');
        if ($templateHeader === null) {
            return;
        }

        $logId = $headers->get('X-Email-Utils-Log-Id')?->getBodyAsString();
        if ($logId === null) {
            return;
        }

        $templateKey = $templateHeader->getBodyAsString();
        $notification = $headers->get('X-Email-Utils-Notification')?->getBodyAsString();
        $messageId = $headers->get('Message-ID')?->getBodyAsString();

        $html = method_exists($message, 'getHtmlBody') ? $message->getHtmlBody() : null;
        $text = method_exists($message, 'getTextBody') ? $message->getTextBody() : null;
        $subject = method_exists($message, 'getSubject') ? $message->getSubject() : null;

        $toEmail = null;
        if (method_exists($message, 'getTo')) {
            $recipients = $message->getTo();
            if (is_array($recipients) && !empty($recipients)) {
                $toEmail = implode(', ', array_keys($recipients));
            }
        }

        $log = EmailLog::query()->where('log_uuid', $logId)->first();
        if (!$log) {
            $log = new EmailLog();
            $log->log_uuid = $logId;
            $log->template_key = $templateKey;
            $log->notification = $notification ?? 'mail';
            $log->status = 'sent';
            $log->sent_at = now();
        }

        if ($log->template_key === null) {
            $log->template_key = $templateKey;
        }

        if ($log->notification === null) {
            $log->notification = $notification ?? 'mail';
        }

        if ($log->to_email === null && $toEmail !== null) {
            $log->to_email = $toEmail;
        }

        if ($log->subject === null && $subject !== null) {
            $log->subject = $subject;
        }

        if ($log->html === null && $html !== null) {
            $log->html = $html;
        }

        if ($log->text === null && $text !== null) {
            $log->text = $text;
        }

        if ($log->message_id === null && $messageId !== null) {
            $log->message_id = $messageId;
        }

        $log->save();
    }
}
