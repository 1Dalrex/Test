<?php

namespace Pterodactyl\Providers;

use Illuminate\Support\Facades\Event;
use Illuminate\Mail\Events\MessageSent;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\ServiceProvider;
use Pterodactyl\Http\Middleware\AdminAuthenticate;
use Pterodactyl\Http\Middleware\RequireTwoFactorAuthentication;
use Pterodactyl\Listeners\EmailUtils\MailSentListener;
use Pterodactyl\Listeners\EmailUtils\NotificationLogSubscriber;

class EmailUtilsServiceProvider extends ServiceProvider
{
    public function register(): void
    {
        $this->mergeConfigFrom(base_path('config/emailutils.php'), 'emailutils');
    }

    public function boot(): void
    {
        $this->loadViewsFrom(base_path('resources/views/emailutils'), 'emailutils');

        Route::middleware(['web', 'auth.session', RequireTwoFactorAuthentication::class, AdminAuthenticate::class])
            ->prefix('/admin')
            ->group(base_path('routes/emailutils.php'));

        Event::subscribe(NotificationLogSubscriber::class);
        Event::listen(MessageSent::class, [MailSentListener::class, 'handle']);
    }
}
