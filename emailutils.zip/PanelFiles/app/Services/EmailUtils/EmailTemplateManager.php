<?php

namespace Pterodactyl\Services\EmailUtils;

use Carbon\CarbonImmutable;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Support\Arr;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use Pterodactyl\Models\EmailTemplate;
use Pterodactyl\Notifications\AccountCreated;
use Pterodactyl\Notifications\AddedToServer;
use Pterodactyl\Notifications\MailTested;
use Pterodactyl\Notifications\RemovedFromServer;
use Pterodactyl\Notifications\SendPasswordReset;
use Pterodactyl\Notifications\ServerInstalled;

class EmailTemplateManager
{
    private static ?\WeakMap $metaStore = null;

    public static function apply(string $key, MailMessage $message, array $data, ?string $notificationClass = null, ?object $notification = null): MailMessage
    {
        return app(self::class)->applyTemplate($key, $message, $data, $notificationClass, $notification);
    }

    public static function applyFromNotification(object $notification, mixed $notifiable, MailMessage $message): MailMessage
    {
        $key = self::resolveTemplateKey($notification);
        if ($key === null) {
            return $message;
        }

        $data = self::resolveTemplateData($notification, $notifiable);
        $data = self::mergeNotifiableData($data, $notifiable);
        self::ensureLogId($notification);

        return self::apply($key, $message, $data, $notification::class, $notification);
    }

    public static function syncTemplates(): void
    {
        app(self::class)->syncConfiguredTemplates();
    }

    public static function renderSubject(string $key, array $data): ?string
    {
        return app(self::class)->renderTemplateSubject($key, $data);
    }

    public static function getNotificationMeta(object $notification): array
    {
        return self::metaStore()[$notification] ?? [];
    }

    public static function getLogId(object $notification): ?string
    {
        return self::getNotificationMeta($notification)['log_id'] ?? null;
    }

    public static function resolveTemplateKey(object $notification): ?string
    {
        return match (true) {
            $notification instanceof AccountCreated => 'account_created',
            $notification instanceof SendPasswordReset => 'password_reset',
            $notification instanceof ServerInstalled => 'server_installed',
            $notification instanceof AddedToServer => 'added_to_server',
            $notification instanceof RemovedFromServer => 'removed_from_server',
            $notification instanceof MailTested => 'mail_tested',
            default => null,
        };
    }

    public static function resolveTemplateData(object $notification, mixed $notifiable): array
    {
        if ($notification instanceof AccountCreated) {
            $actionUrl = null;
            if (!is_null($notification->token)) {
                $actionUrl = url('/auth/password/reset/' . $notification->token . '?email=' . urlencode($notification->user->email));
            }

            return [
                'user' => [
                    'name' => $notification->user->name,
                    'email' => $notification->user->email,
                    'username' => $notification->user->username,
                ],
                'token' => $notification->token,
                'action' => [
                    'url' => $actionUrl,
                ],
            ];
        }

        if ($notification instanceof SendPasswordReset) {
            $email = $notifiable?->email ?? '';
            $actionUrl = url('/auth/password/reset/' . $notification->token . '?email=' . urlencode((string) $email));

            return [
                'user' => [
                    'email' => $email,
                ],
                'token' => $notification->token,
                'action' => [
                    'url' => $actionUrl,
                ],
            ];
        }

        if ($notification instanceof ServerInstalled) {
            return [
                'user' => [
                    'username' => $notification->user->username,
                ],
                'server' => [
                    'name' => $notification->server->name,
                ],
                'action' => [
                    'url' => route('index'),
                ],
            ];
        }

        if ($notification instanceof AddedToServer) {
            $uuidShort = $notification->server->uuidShort ?? null;
            $actionUrl = $uuidShort ? url('/server/' . $uuidShort) : null;

            return [
                'user' => [
                    'name' => $notification->server->user ?? null,
                ],
                'server' => [
                    'name' => $notification->server->name ?? null,
                    'uuid_short' => $uuidShort,
                ],
                'action' => [
                    'url' => $actionUrl,
                ],
            ];
        }

        if ($notification instanceof RemovedFromServer) {
            return [
                'user' => [
                    'name' => $notification->server->user ?? null,
                ],
                'server' => [
                    'name' => $notification->server->name ?? null,
                ],
                'action' => [
                    'url' => route('index'),
                ],
            ];
        }

        if ($notification instanceof MailTested) {
            $user = self::resolveMailTestUser($notification, $notifiable);

            return [
                'user' => [
                    'name' => $user?->name ?? null,
                    'email' => $user?->email ?? null,
                ],
            ];
        }

        return [];
    }

    private static function mergeNotifiableData(array $data, mixed $notifiable): array
    {
        if (!is_object($notifiable)) {
            return $data;
        }

        $user = $data['user'] ?? [];
        if (!is_array($user)) {
            $user = [];
        }

        if (!array_key_exists('name', $user)) {
            if (isset($notifiable->name)) {
                $user['name'] = $notifiable->name;
            } elseif (isset($notifiable->name_first) || isset($notifiable->name_last)) {
                $user['name'] = trim((string) ($notifiable->name_first ?? '') . ' ' . (string) ($notifiable->name_last ?? ''));
            }
        }

        if (!array_key_exists('email', $user)) {
            if (isset($notifiable->email)) {
                $user['email'] = $notifiable->email;
            } elseif (method_exists($notifiable, 'routeNotificationFor')) {
                $route = $notifiable->routeNotificationFor('mail');
                if (is_string($route)) {
                    $user['email'] = $route;
                }
            }
        }

        if (!array_key_exists('username', $user) && isset($notifiable->username)) {
            $user['username'] = $notifiable->username;
        }

        if (!empty($user)) {
            $data['user'] = $user;
        }

        return $data;
    }

    private static function resolveMailTestUser(MailTested $notification, mixed $notifiable): mixed
    {
        if (is_object($notifiable) && !$notifiable instanceof \Illuminate\Notifications\AnonymousNotifiable) {
            return $notifiable;
        }

        try {
            $reflection = new \ReflectionClass($notification);
            if ($reflection->hasProperty('user')) {
                $property = $reflection->getProperty('user');
                $property->setAccessible(true);

                return $property->getValue($notification);
            }
        } catch (\ReflectionException) {
            return null;
        }

        return null;
    }

    public function applyTemplate(
        string $key,
        MailMessage $message,
        array $data,
        ?string $notificationClass = null,
        ?object $notification = null
    ): MailMessage
    {
        $template = EmailTemplate::query()->where('key', $key)->first();
        $data = $this->withBaseData($data);
        $renderedSubject = null;
        $renderedHtml = null;
        $renderedText = null;

        if (!$template || !$template->is_active) {
            return $this->attachHeaders($message, $key, $notificationClass, $notification);
        }

        $renderedSubject = $this->renderString((string) $template->subject, $data);
        if ($renderedSubject !== '') {
            $message->subject($renderedSubject);
        }

        $html = $this->resolveHtml($template);
        $text = $template->text;

        if ($html !== null) {
            $renderedHtml = $this->renderString($html, $data);
            $message->view('emailutils::mail.custom', [
                'html' => $renderedHtml,
                'data' => $data,
            ]);
        }

        if ($text !== null && $text !== '') {
            $renderedText = $this->renderString($text, $data);
            $message->text('emailutils::mail.custom_plain', [
                'text' => $renderedText,
                'data' => $data,
            ]);
        }

        if ($notification !== null) {
            self::storeNotificationMeta($notification, [
                'subject' => $renderedSubject,
                'html' => $renderedHtml,
                'text' => $renderedText,
            ]);
        }

        return $this->attachHeaders($message, $key, $notificationClass, $notification);
    }

    public function renderTemplateSubject(string $key, array $data): ?string
    {
        $template = EmailTemplate::query()->where('key', $key)->first();
        if (!$template) {
            return null;
        }

        $subject = $this->renderString((string) $template->subject, $this->withBaseData($data));
        return $subject !== '' ? $subject : null;
    }

    public function syncConfiguredTemplates(): void
    {
        $templates = config('emailutils.templates', []);

        foreach ($templates as $key => $template) {
            $attributes = [
                'key' => $key,
            ];

            $values = [
                'name' => Arr::get($template, 'name', $key),
                'subject' => Arr::get($template, 'default_subject'),
                'is_active' => false,
            ];

            EmailTemplate::query()->firstOrCreate($attributes, $values);
        }
    }

    private function withBaseData(array $data): array
    {
        return array_replace_recursive([
            'app' => [
                'name' => (string) config('app.name'),
            ],
            'panel' => [
                'url' => (string) config('app.url'),
            ],
            'timestamp' => CarbonImmutable::now()->toDateTimeString(),
        ], $data);
    }

    private function resolveHtml(EmailTemplate $template): ?string
    {
        if (!empty($template->html_file_path)) {
            $disk = config('emailutils.storage_disk', 'local');
            $path = ltrim($template->html_file_path, '/');

            if (Storage::disk($disk)->exists($path)) {
                return Storage::disk($disk)->get($path);
            }
        }

        return $template->html;
    }

    private function renderString(string $value, array $data): string
    {
        if ($value === '') {
            return '';
        }

        return (string) preg_replace_callback('/\{\{\s*([a-zA-Z0-9_.]+)\s*\}\}/', function ($matches) use ($data) {
            $replacement = data_get($data, $matches[1]);

            if (is_scalar($replacement) || $replacement === null) {
                return (string) ($replacement ?? '');
            }

            return '';
        }, $value);
    }

    private function attachHeaders(MailMessage $message, string $key, ?string $notificationClass, ?object $notification): MailMessage
    {
        $logId = $notification ? self::getLogId($notification) : null;

        $message->withSymfonyMessage(function ($email) use ($key, $notificationClass, $logId) {
            $email->getHeaders()->addTextHeader('X-Email-Utils-Template', $key);
            if ($notificationClass !== null) {
                $email->getHeaders()->addTextHeader('X-Email-Utils-Notification', $notificationClass);
            }
            if ($logId !== null) {
                $email->getHeaders()->addTextHeader('X-Email-Utils-Log-Id', $logId);
            }
        });

        return $message;
    }

    private static function metaStore(): \WeakMap
    {
        if (self::$metaStore === null) {
            self::$metaStore = new \WeakMap();
        }

        return self::$metaStore;
    }

    private static function ensureLogId(object $notification): string
    {
        $meta = self::getNotificationMeta($notification);
        if (!isset($meta['log_id'])) {
            $meta['log_id'] = (string) Str::uuid();
            self::metaStore()[$notification] = $meta;
        }

        return $meta['log_id'];
    }

    private static function storeNotificationMeta(object $notification, array $meta): void
    {
        $existing = self::getNotificationMeta($notification);
        self::metaStore()[$notification] = array_replace($existing, array_filter($meta, static function ($value) {
            return $value !== null;
        }));
    }
}
