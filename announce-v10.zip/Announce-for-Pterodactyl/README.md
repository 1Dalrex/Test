# Announce for Blueprint

Announce for Pterodactyl (Blueprint)


## Prerequisites
1. Pterodactyl (pterodactyl.io) with Blueprint (blueprint.zip)
2. Announce account (announce.layeredy.com)

## How to install
1. Download the latest **.blueprint** file from [here](https://git.layeredy.com/announce/blueprint/releases)
2. Upload the file to your Pterodactyl directory (Commonly ``/var/www/pterodactyl``)
3. Run ``blueprint -install lyrdyannounce.blueprint``

**You finished! Now you can configure it via the admin panel (Click the puzzle piece in the top right and then "Announce")**

## Reporting bugs

### Announce bugs
If your bug is relating to Announce, please report it [here](https://forum.layeredy.com/forums/requests/), if it's related to a security issue, please follow [this](https://layeredy.com/security-policy/)

### Announce for Blueprint bugs
Follow same guidelines as Announce

### Blueprint bugs
Report Blueprint bugs [here](https://github.com/orgs/BlueprintFramework/discussions/categories/support) 
