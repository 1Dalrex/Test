Thank you for installing Show Node IDs.

DISCLAIMER: THIS VERSION ONLY WORKS WITHOUT BLUEPRINT, IF YOU DON'T HAVE BLUEPRINT INSTALLED PLEASE USE THE OTHER FOLDER NAMED "WITHOUT BLUEPRINT"

1. Drag the "resources" folder into your Pterodactyl folder (usually /var/www/pterodactyl).

2. Run this command: "yarn build:production" (when cd'd into /var/www/pterodactyl)

3. Finished, for support please join our Discord server, https://discord.gg/eJfgfFtZ2r