      _____           _____
  ,ad8PPPP88b,     ,d88PPPP8ba,       
 d8P"      "Y8b, ,d8P"      "Y8b      
dP'           "8a8"           `Yd     
8(              "              )8     
I8                             8I     Hello, thank you for installing my addon on BuiltByBit, but
 Yb,         From me         ,dP      I highly recommend to install addon with one line command
  "8a,       For you       ,a8"       
    "8a,                 ,a8"         bash <(curl https://exeyarikus.info/pterodactyl-region/install)
      "Yba             adP"           
        `Y8a         a8P'             Just one command and addon can be installed, but anyway thanks
          `88,     ,88'               you for installing, have a nice day :>
            "8b   d8"  
             "8b d8"   
              `888'
                "