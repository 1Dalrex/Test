\## Manual installation

1\. Upload all file from the `upload` folders into `/var/www/pterodactyl`

2\. Go To `resources/views/layouts/admin.blade.php` and below

```

<li class="{{ ! starts\_with(Route::currentRouteName(), 'admin.databases') ?: 'active' }}">

&nbsp;   <a href="{{ route('admin.databases') }}">

&nbsp;       <i class="fa fa-database"></i> <span>Databases</span>

&nbsp;   </a>

</li>

```

add

```

<li class="{{ ! starts\_with(Route::currentRouteName(), 'admin.activitypurges') ?: 'active' }}">

&nbsp;   <a href="{{ route('admin.activitypurges')}}">

&nbsp;       <i class="fa fa-eraser"></i> <span>Activity Purges</span>

&nbsp;   </a>

</li>

```

3\. Go To `routes/admin.php` and at the end of file add

```

/\*

|--------------------------------------------------------------------------

| Activity Purges Controller Routes

|--------------------------------------------------------------------------

|

| Endpoint: /admin/activitypurges

|

\*/

Route::prefix('/activitypurges')->group(function () {

&nbsp;   Route::get('/', \[Admin\\ActivityPurgesController::class, 'index'])->name('admin.activitypurges');

&nbsp;   Route::post('/', \[Admin\\ActivityPurgesController::class, 'post']);

});

```

