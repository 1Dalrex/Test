<?php

namespace Pterodactyl\Http\Controllers\Admin;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Pterodactyl\Http\Controllers\Controller;

class ActivityPurgesController extends Controller
{
    /**
     * Show purge page.
     */
    public function index(Request $request)
    {
        return view('admin.activitypurges.index', [
            'message' => session('message'), // flash message from redirect
        ]);
    }

    /**
     * Handle purge POST.
     */
    public function post(Request $request)
    {
        $validated = $request->validate([
            'tables'    => 'required|array',
            'tables.*'  => 'in:activity_logs,api_logs,audit_logs',
            'timestamp' => 'required_without:quick|nullable|date',
            'quick'     => 'nullable|in:7,14,30,90,180,365',
        ]);

        // Determine cutoff timestamp
        if (!empty($validated['quick'])) {
            $days = (int) $validated['quick'];
            $mysqlTimestamp = now()->subDays($days)->format('Y-m-d H:i:s');
        } else {
            $rawTimestamp = $validated['timestamp'];
            $mysqlTimestamp = date('Y-m-d H:i:s', strtotime($rawTimestamp));
        }

        // Map table → column
        $columnsMapping = [
            'activity_logs' => 'timestamp',
            'api_logs'      => 'updated_at',
            'audit_logs'    => 'created_at',
        ];

        $deletedRecords = [];
        try {
            foreach ($validated['tables'] as $table) {
                $dateColumn = $columnsMapping[$table] ?? 'timestamp';

                $deleted = DB::table($table)
                    ->where($dateColumn, '<', $mysqlTimestamp)
                    ->delete();

                $deletedRecords[$table] = $deleted;
            }

            $msgParts = [];
            foreach ($deletedRecords as $table => $count) {
                $msgParts[] = "{$table}: {$count} log(s)";
            }
            $message = "Purged records - " . implode(", ", $msgParts);
        } catch (\Exception $e) {
            \Log::error('Purge error: ' . $e->getMessage());
            $message = "An error occurred while purging logs.";
        }

        return redirect()
            ->route('admin.activitypurges')
            ->with('message', $message);
    }
}
