@extends('layouts.admin')

@section('title')
    Activity Purges
@endsection

@section('content-header')
    <h1>Activity Purges<small>Clean up database log tables</small></h1>
@endsection

@section('content')
<div class="box box-info">
  <div class="box-header with-border">
    <h3 class="box-title">Information</h3>
  </div>
  <div class="box-body">
    <p>
      This tool allows you to <code>clear</code> selected logs to reduce database storage usage.
    </p>
  </div>
</div>

<div class="box box-info">
  <div class="box-header with-border">
    <h3 class="box-title">Management</h3>
  </div>
  <div class="box-body">
    @if($message)
      <div class="alert alert-success">
        {{ $message }}
      </div>
    @endif

    <form method="POST" action="{{ route('admin.activitypurges') }}" autocomplete="off">
      @csrf

      <!-- Select tables -->
      <div class="form-group">
        <label>Tables</label>
        <div class="d-flex">
          <label class="mr-3">
            <input type="checkbox" name="tables[]" value="activity_logs"> Activity Logs
          </label>
          <label class="mr-3">
            <input type="checkbox" name="tables[]" value="api_logs"> API Logs
          </label>
          <label>
            <input type="checkbox" name="tables[]" value="audit_logs"> Audit Logs
          </label>
        </div>
      </div>

      <!-- Quick delete buttons -->
      <div class="form-group">
        <label>Quick Action</label>
        <div class="d-flex align-items-center">
          <button type="submit" name="quick" value="7" class="btn btn-danger mr-2">1 Week</button>
          <button type="submit" name="quick" value="14" class="btn btn-danger mr-2">2 Weeks</button>
          <button type="submit" name="quick" value="30" class="btn btn-danger mr-2">1 Month</button>
          <button type="submit" name="quick" value="90" class="btn btn-danger mr-2">3 Months</button>
          <button type="submit" name="quick" value="180" class="btn btn-danger mr-2">6 Months</button>
          <button type="submit" name="quick" value="365" class="btn btn-danger">1 Year</button>
        </div>
      </div>

      <!-- Manual purge -->
      <div class="form-group">
        <label for="timestamp">Manual Purge</label>
        <input type="datetime-local" name="timestamp" id="timestamp" class="form-control">
      </div>

      <button type="submit" class="btn btn-danger">Purge</button>
    </form>
  </div>
</div>
@endsection
