1. Upload s3manager.blueprint into pterodactyl folder (default: "/var/www/pterodactyl")
2. Run "blueprint -i s3manager.blueprint"
3. Go To Pterodactyl Admin Area and manages the extension.