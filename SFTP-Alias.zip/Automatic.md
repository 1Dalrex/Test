\## Automatic installation

1\. Upload file `sftp-alias.patch` into `/var/www/pterodactyl`

2\. run this command inside `/var/www/pterodactyl`

```sh

sudo apt install git -y \&\& git apply sftp-alias.patch

```

