## Manual installation
1. Upload all file from the `upload` folders into `/var/www/pterodactyl`
2. Go To `app/Console/Commands/Node/MakeNodeCommand.php` and below 
```
{--fqdn= : The domain name (e.g node.example.com) to be used for connecting to the daemon. An IP address may only be used if you are not using SSL for this node.}
```
add
```
{--sftpAlias= : The SFTP hostname alias (e.g sftp.example.com) to be used for connecting to the SFTP server. An IP address may only be used if you are not using SSL for this node.}
```
3. below this code
```
$data['daemonBase'] = $this->option('daemonBase') ?? $this->ask('Enter the base folder', '/var/lib/pterodactyl/volumes');
```
add
```
$data['sftp_alias'] = $this->option('sftpAlias') ?? $this->ask('Enter the SFTP hostname alias (e.g sftp.example.com) to be used for connecting to the SFTP server. An IP address may only be used if you are not using SSL for this node');
```
4. Go To `app/Http/Controllers/Admin/Nodes/NodeViewController.php` and search
```
->only(['scheme', 'fqdn', 'daemonListen', 'daemon_token_id', 'daemon_token']),
```
and replace it to
```
->only(['scheme', 'fqdn', 'daemonListen', 'daemon_token_id', 'daemon_token', 'sftp_alias']),
```
5. Go To `app/Http/Controllers/Api/Application/Nodes/NodeController.php` and search
```
->allowedSorts(['id', 'uuid', 'memory', 'disk'])
```
and replace it to
```
->allowedSorts(['id', 'uuid', 'memory', 'disk', 'sftp_alias'])
```
6. Go To `app/Http/Requests/Admin/Node/NodeFormRequest.php` and below
```
$data['fqdn'][] = Fqdn::make('scheme');
```
add
```
$data['sftp_alias'][] = Fqdn::make('scheme');
```
7. Go To `app/Http/Requests/Api/Application/Nodes/StoreNodeRequest.php` and below
```
'daemonListen',
'daemonSFTP',
'daemonBase',
```
add
```
'sftp_alias',
```
8. Go To `app/Models/Node.php` and below
```
'disk_overallocate', 'upload_size', 'daemonBase',
'daemonSFTP', 'daemonListen',
'description', 'maintenance_mode',
```
add
```
'sftp_alias',
```
9. below this code
```
'daemonListen' => 'required|numeric|between:1,65535',
'maintenance_mode' => 'boolean',
'upload_size' => 'int|between:1,1024',
```
add
```
'sftp_alias' => 'string|nullable',
```
10. Go To `app/Repositories/Eloquent/NodeRepository.php` and search
```
->select(['nodes.id', 'nodes.fqdn', 'nodes.scheme', 'nodes.daemon_token', 'nodes.daemonListen', 'nodes.memory', 'nodes.disk', 'nodes.memory_overallocate', 'nodes.disk_overallocate'])
```
and replace it to
```
->select(['nodes.id', 'nodes.fqdn', 'nodes.scheme', 'nodes.daemon_token', 'nodes.daemonListen', 'nodes.memory', 'nodes.disk', 'nodes.memory_overallocate', 'nodes.disk_overallocate', 'nodes.sftp_alias'])
```
11. Go To `app/Services/Nodes/NodeUpdateService.php` and below
```
$node->fqdn = $updated->fqdn;
```
add
```
$node->sftp_alias = $updated->sftp_alias;
```
12. Go To `app/Transformers/Api/Client/ServerTransformer.php` and search
```
'ip' => $server->node->fqdn,
```
and replace it to
```
'ip' => $server->node->sftp_alias ?? $server->node->fqdn,
```
13. Go To `database/Factories/NodeFactory.php` and below
```
'daemonListen' => 8080,
'daemonSFTP' => 2022,
'daemonBase' => '/var/lib/pterodactyl/volumes',
```
add
```
'sftp_alias' => $this->faker->unique()->ipv4,
```
15. Go To `resources/views/admin/nodes/view/settings.blade.php` and below
```
<div class="form-group col-xs-12">
    <label for="disk_overallocate" class="control-label">Maximum Web Upload Filesize</label>
    <div class="input-group">
        <input type="text" name="upload_size" class="form-control" value="{{ old('upload_size', $node->upload_size) }}"/>
        <span class="input-group-addon">MiB</span>
    </div>
    <p class="text-muted"><small>Enter the maximum size of files that can be uploaded through the web-based file manager.</small></p>
</div>
```
add
```
<div class="form-group col-xs-12">
    <label for="sftp_alias" class="control-label">SFTP Hostname Alias</label>
    <div>
        <input type="text" autocomplete="off" name="sftp_alias" class="form-control" value="{{ old('sftp_alias', $node->sftp_alias) }}" />
    </div>
    <p class="text-muted"><small>Please enter SFTP Hostname alias (e.g <code>sftp.example.com</code>) to be used for client connecting to SFTP. An IP address may only be used if you are not using SSL for this node.
            <a tabindex="0" data-toggle="popover" data-trigger="focus" title="Why do I need a FQDN?" data-content="In order to secure communications between your server and this node we use SSL. We cannot generate a SSL certificate for IP Addresses, and as such you will need to provide a FQDN.">Why?</a>
        </small></p>
</div>
```