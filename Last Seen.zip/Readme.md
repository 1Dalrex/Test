## Manual installation
1. Upload all file from the `upload` folders into `/var/www/pterodactyl`
2. Go To `app\Http\Controllers\Admin\UserController.php` and search
```
->allowedFilters(['username', 'email', 'uuid'])
```
then replace it with
```
->allowedFilters(['username', 'email', 'uuid', 'last_seen_at'])
```
3. Go To `app\Http\Kernel.php` and below
```
use Illuminate\Session\Middleware\StartSession;
```
add
```
use Pterodactyl\Http\Middleware\UpdateLastSeen;
```
4. Go To `app\Http\Kernel.php` and below
```
VerifyCsrfToken::class,
```
add
```
UpdateLastSeen::class,
```
5. Go To `app\Models\User.php` and below
```
'totp_authenticated_at' => 'datetime',
```
add
```
'last_seen_at' => 'datetime',
```
6. Go To `resources\views\admin\users\index.blade.php` and below
```
<th class="text-center"><span data-toggle="tooltip" data-placement="top" title="Servers that this user can access because they are marked as a subuser.">Can Access</span></th>
```
add
```
<th>Last Seen</th>
```
7. Go To `resources\views\admin\users\index.blade.php` and below
```
<td class="text-center">{{ $user->subuser_of_count }}</td>
```
add
```
<td>
    @if($user->last_seen_at)
        @if($user->last_seen_at->gt(now()->subMinutes(5)))
            <i class="fas fa-circle" style="color: #00ad45ff;"></i> Online
        @else
            <i class="fas fa-circle text-red"></i> {{ $user->last_seen_at->diffForHumans() }}
        @endif
    @else
        <i class="fas fa-circle text-muted"></i> Never
    @endif
</td>
```
8. Run This Command
```
php artisan migrate
```